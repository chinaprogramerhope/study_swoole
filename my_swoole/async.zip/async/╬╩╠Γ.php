1. 后台启动server, 怎么关闭
2. nginx反向代理